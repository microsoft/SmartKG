// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
var urlapi = "http://localhost:5000"