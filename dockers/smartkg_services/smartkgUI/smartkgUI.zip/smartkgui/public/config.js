// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
var urlapi = "https://localhost:5001"